﻿namespace DarmoweSMSy
{
    partial class GlowneOkno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GlowneOkno));
            this.przyciskwyslij = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pudelkonauzytkowanika = new System.Windows.Forms.TextBox();
            this.pudelkonahaslo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pudelkonatelefon = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pudelkonaatresc = new System.Windows.Forms.TextBox();
            this.etykietatresc = new System.Windows.Forms.Label();
            this.add_to_favourite = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.del_from_favourites = new System.Windows.Forms.Button();
            this.exit_program = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otwórzToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zapiszToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wyjścieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edycjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czcionkaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kolorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.widokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ukryjToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.przyciskZamknieciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeUlubionychToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pokazToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.przyciskZamknięciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeUlubionychToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pomocToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oMnieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Tlo = new System.Windows.Forms.PictureBox();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.use_this = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tlo)).BeginInit();
            this.SuspendLayout();
            // 
            // przyciskwyslij
            // 
            this.przyciskwyslij.Location = new System.Drawing.Point(353, 310);
            this.przyciskwyslij.Name = "przyciskwyslij";
            this.przyciskwyslij.Size = new System.Drawing.Size(115, 72);
            this.przyciskwyslij.TabIndex = 0;
            this.przyciskwyslij.Text = "Wyślij";
            this.przyciskwyslij.UseVisualStyleBackColor = true;
            this.przyciskwyslij.Click += new System.EventHandler(this.przyciskwyslij_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nazwa Użytkowanika:";
            // 
            // pudelkonauzytkowanika
            // 
            this.pudelkonauzytkowanika.AutoCompleteCustomSource.AddRange(new string[] {
            "wiki-57@o2.pl",
            "wiki-58@o2.pl",
            "asdasdasd"});
            this.pudelkonauzytkowanika.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pudelkonauzytkowanika.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.pudelkonauzytkowanika.Location = new System.Drawing.Point(156, 28);
            this.pudelkonauzytkowanika.Name = "pudelkonauzytkowanika";
            this.pudelkonauzytkowanika.Size = new System.Drawing.Size(137, 20);
            this.pudelkonauzytkowanika.TabIndex = 2;
            // 
            // pudelkonahaslo
            // 
            this.pudelkonahaslo.Location = new System.Drawing.Point(156, 54);
            this.pudelkonahaslo.Name = "pudelkonahaslo";
            this.pudelkonahaslo.Size = new System.Drawing.Size(137, 20);
            this.pudelkonahaslo.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Hasło:";
            // 
            // pudelkonatelefon
            // 
            this.pudelkonatelefon.AutoCompleteCustomSource.AddRange(new string[] {
            "606228504",
            "345678890",
            "123645123",
            "000000000",
            "345678534",
            "890864654"});
            this.pudelkonatelefon.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.pudelkonatelefon.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.pudelkonatelefon.Location = new System.Drawing.Point(156, 80);
            this.pudelkonatelefon.Name = "pudelkonatelefon";
            this.pudelkonatelefon.Size = new System.Drawing.Size(137, 20);
            this.pudelkonatelefon.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Numer telefonu:";
            // 
            // pudelkonaatresc
            // 
            this.pudelkonaatresc.Location = new System.Drawing.Point(85, 133);
            this.pudelkonaatresc.Multiline = true;
            this.pudelkonaatresc.Name = "pudelkonaatresc";
            this.pudelkonaatresc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.pudelkonaatresc.Size = new System.Drawing.Size(383, 151);
            this.pudelkonaatresc.TabIndex = 8;
            // 
            // etykietatresc
            // 
            this.etykietatresc.AutoSize = true;
            this.etykietatresc.Location = new System.Drawing.Point(37, 136);
            this.etykietatresc.Name = "etykietatresc";
            this.etykietatresc.Size = new System.Drawing.Size(34, 13);
            this.etykietatresc.TabIndex = 7;
            this.etykietatresc.Text = "Treść";
            // 
            // add_to_favourite
            // 
            this.add_to_favourite.Location = new System.Drawing.Point(331, 28);
            this.add_to_favourite.Name = "add_to_favourite";
            this.add_to_favourite.Size = new System.Drawing.Size(52, 24);
            this.add_to_favourite.TabIndex = 9;
            this.add_to_favourite.Text = "Dodaj do ulubionych";
            this.add_to_favourite.UseVisualStyleBackColor = true;
            this.add_to_favourite.Click += new System.EventHandler(this.add_to_favourite_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "wiki-58@o2.pl",
            "1",
            "w"});
            this.comboBox1.Location = new System.Drawing.Point(486, 31);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 10;
            // 
            // del_from_favourites
            // 
            this.del_from_favourites.Location = new System.Drawing.Point(393, 28);
            this.del_from_favourites.Name = "del_from_favourites";
            this.del_from_favourites.Size = new System.Drawing.Size(46, 24);
            this.del_from_favourites.TabIndex = 11;
            this.del_from_favourites.Text = "Usuń z ulubionych";
            this.del_from_favourites.UseVisualStyleBackColor = true;
            this.del_from_favourites.Click += new System.EventHandler(this.del_from_favourites_Click);
            // 
            // exit_program
            // 
            this.exit_program.Location = new System.Drawing.Point(521, 313);
            this.exit_program.Name = "exit_program";
            this.exit_program.Size = new System.Drawing.Size(128, 68);
            this.exit_program.TabIndex = 12;
            this.exit_program.Text = "Zamknij Program";
            this.exit_program.UseVisualStyleBackColor = true;
            this.exit_program.Click += new System.EventHandler(this.exit_program_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plikToolStripMenuItem,
            this.edycjaToolStripMenuItem,
            this.widokToolStripMenuItem,
            this.pomocToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(670, 24);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plikToolStripMenuItem
            // 
            this.plikToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.otwórzToolStripMenuItem,
            this.zapiszToolStripMenuItem,
            this.wyjścieToolStripMenuItem});
            this.plikToolStripMenuItem.Name = "plikToolStripMenuItem";
            this.plikToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.plikToolStripMenuItem.Text = "Plik";
            // 
            // otwórzToolStripMenuItem
            // 
            this.otwórzToolStripMenuItem.Image = global::DarmoweSMSy.Properties.Resources.Open;
            this.otwórzToolStripMenuItem.Name = "otwórzToolStripMenuItem";
            this.otwórzToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.otwórzToolStripMenuItem.Text = "Otwórz";
            this.otwórzToolStripMenuItem.Click += new System.EventHandler(this.otwórzToolStripMenuItem_Click);
            // 
            // zapiszToolStripMenuItem
            // 
            this.zapiszToolStripMenuItem.Image = global::DarmoweSMSy.Properties.Resources.Save;
            this.zapiszToolStripMenuItem.Name = "zapiszToolStripMenuItem";
            this.zapiszToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.zapiszToolStripMenuItem.Text = "Zapisz";
            this.zapiszToolStripMenuItem.Click += new System.EventHandler(this.zapiszToolStripMenuItem_Click);
            // 
            // wyjścieToolStripMenuItem
            // 
            this.wyjścieToolStripMenuItem.Image = global::DarmoweSMSy.Properties.Resources.Exit;
            this.wyjścieToolStripMenuItem.Name = "wyjścieToolStripMenuItem";
            this.wyjścieToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.wyjścieToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.wyjścieToolStripMenuItem.Text = "Wyjście";
            this.wyjścieToolStripMenuItem.Click += new System.EventHandler(this.wyjścieToolStripMenuItem_Click);
            // 
            // edycjaToolStripMenuItem
            // 
            this.edycjaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.czcionkaToolStripMenuItem,
            this.kolorToolStripMenuItem});
            this.edycjaToolStripMenuItem.Name = "edycjaToolStripMenuItem";
            this.edycjaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.edycjaToolStripMenuItem.Text = "Edycja";
            // 
            // czcionkaToolStripMenuItem
            // 
            this.czcionkaToolStripMenuItem.Image = global::DarmoweSMSy.Properties.Resources.Select_All;
            this.czcionkaToolStripMenuItem.Name = "czcionkaToolStripMenuItem";
            this.czcionkaToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.czcionkaToolStripMenuItem.Text = "Czcionka";
            this.czcionkaToolStripMenuItem.Click += new System.EventHandler(this.czcionkaToolStripMenuItem_Click);
            // 
            // kolorToolStripMenuItem
            // 
            this.kolorToolStripMenuItem.Image = global::DarmoweSMSy.Properties.Resources.Select_All;
            this.kolorToolStripMenuItem.Name = "kolorToolStripMenuItem";
            this.kolorToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.kolorToolStripMenuItem.Text = "Kolor";
            this.kolorToolStripMenuItem.Click += new System.EventHandler(this.kolorToolStripMenuItem_Click);
            // 
            // widokToolStripMenuItem
            // 
            this.widokToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ukryjToolStripMenuItem,
            this.pokazToolStripMenuItem});
            this.widokToolStripMenuItem.Name = "widokToolStripMenuItem";
            this.widokToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.widokToolStripMenuItem.Text = "Widok";
            // 
            // ukryjToolStripMenuItem
            // 
            this.ukryjToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.przyciskZamknieciaToolStripMenuItem,
            this.listeUlubionychToolStripMenuItem});
            this.ukryjToolStripMenuItem.Name = "ukryjToolStripMenuItem";
            this.ukryjToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.ukryjToolStripMenuItem.Text = "Ukryj";
            // 
            // przyciskZamknieciaToolStripMenuItem
            // 
            this.przyciskZamknieciaToolStripMenuItem.Name = "przyciskZamknieciaToolStripMenuItem";
            this.przyciskZamknieciaToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.przyciskZamknieciaToolStripMenuItem.Text = "Przycisk zamkniecia";
            this.przyciskZamknieciaToolStripMenuItem.Click += new System.EventHandler(this.przyciskZamknieciaToolStripMenuItem_Click);
            // 
            // listeUlubionychToolStripMenuItem
            // 
            this.listeUlubionychToolStripMenuItem.Name = "listeUlubionychToolStripMenuItem";
            this.listeUlubionychToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.listeUlubionychToolStripMenuItem.Text = "Liste Ulubionych";
            this.listeUlubionychToolStripMenuItem.Click += new System.EventHandler(this.listeUlubionychToolStripMenuItem_Click);
            // 
            // pokazToolStripMenuItem
            // 
            this.pokazToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.przyciskZamknięciaToolStripMenuItem,
            this.listeUlubionychToolStripMenuItem1});
            this.pokazToolStripMenuItem.Name = "pokazToolStripMenuItem";
            this.pokazToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.pokazToolStripMenuItem.Text = "Pokaż";
            // 
            // przyciskZamknięciaToolStripMenuItem
            // 
            this.przyciskZamknięciaToolStripMenuItem.Name = "przyciskZamknięciaToolStripMenuItem";
            this.przyciskZamknięciaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.przyciskZamknięciaToolStripMenuItem.Text = "Przycisk Zamknięcia";
            this.przyciskZamknięciaToolStripMenuItem.Click += new System.EventHandler(this.przyciskZamknięciaToolStripMenuItem_Click);
            // 
            // listeUlubionychToolStripMenuItem1
            // 
            this.listeUlubionychToolStripMenuItem1.Name = "listeUlubionychToolStripMenuItem1";
            this.listeUlubionychToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.listeUlubionychToolStripMenuItem1.Text = "Liste Ulubionych";
            this.listeUlubionychToolStripMenuItem1.Click += new System.EventHandler(this.listeUlubionychToolStripMenuItem1_Click);
            // 
            // pomocToolStripMenuItem
            // 
            this.pomocToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oMnieToolStripMenuItem});
            this.pomocToolStripMenuItem.Name = "pomocToolStripMenuItem";
            this.pomocToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.pomocToolStripMenuItem.Text = "Pomoc";
            // 
            // oMnieToolStripMenuItem
            // 
            this.oMnieToolStripMenuItem.Image = global::DarmoweSMSy.Properties.Resources.Help;
            this.oMnieToolStripMenuItem.Name = "oMnieToolStripMenuItem";
            this.oMnieToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.oMnieToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.oMnieToolStripMenuItem.Text = "O mnie";
            this.oMnieToolStripMenuItem.Click += new System.EventHandler(this.oMnieToolStripMenuItem_Click);
            // 
            // Tlo
            // 
            this.Tlo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Tlo.Image = ((System.Drawing.Image)(resources.GetObject("Tlo.Image")));
            this.Tlo.Location = new System.Drawing.Point(0, 27);
            this.Tlo.Name = "Tlo";
            this.Tlo.Size = new System.Drawing.Size(670, 420);
            this.Tlo.TabIndex = 14;
            this.Tlo.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // use_this
            // 
            this.use_this.Location = new System.Drawing.Point(486, 59);
            this.use_this.Name = "use_this";
            this.use_this.Size = new System.Drawing.Size(121, 23);
            this.use_this.TabIndex = 15;
            this.use_this.Text = "Użyj tego";
            this.use_this.UseVisualStyleBackColor = true;
            this.use_this.Click += new System.EventHandler(this.use_this_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(85, 313);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(77, 17);
            this.checkBox1.TabIndex = 16;
            this.checkBox1.Text = "Auto Zapis";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // GlowneOkno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(670, 394);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.use_this);
            this.Controls.Add(this.exit_program);
            this.Controls.Add(this.del_from_favourites);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.add_to_favourite);
            this.Controls.Add(this.pudelkonaatresc);
            this.Controls.Add(this.etykietatresc);
            this.Controls.Add(this.pudelkonatelefon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pudelkonahaslo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pudelkonauzytkowanika);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.przyciskwyslij);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.Tlo);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "GlowneOkno";
            this.Text = "Wyślij wiadomość SMS";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tlo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button przyciskwyslij;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox pudelkonauzytkowanika;
        private System.Windows.Forms.TextBox pudelkonahaslo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox pudelkonatelefon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox pudelkonaatresc;
        private System.Windows.Forms.Label etykietatresc;
        private System.Windows.Forms.Button add_to_favourite;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button del_from_favourites;
        private System.Windows.Forms.Button exit_program;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wyjścieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edycjaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem widokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pomocToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oMnieToolStripMenuItem;
        private System.Windows.Forms.PictureBox Tlo;
        private System.Windows.Forms.ToolStripMenuItem czcionkaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kolorToolStripMenuItem;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem zapiszToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem otwórzToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ukryjToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem przyciskZamknieciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeUlubionychToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pokazToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem przyciskZamknięciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeUlubionychToolStripMenuItem1;
        private System.Windows.Forms.Button use_this;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}

